# Roam eSIM backend (Lemon Squeezy edition)

Handles payment (Lemon Squeezy) and eSIM provisioning for the Roam storefront.

## 1. Set up Lemon Squeezy

1. Create a Product in your Lemon Squeezy dashboard for each plan in `plans.js`
2. For each product, find its **Variant ID** (Products → click the product →
   the variant ID is shown in the variant details, or in the URL when you
   click into it)
3. Paste each Variant ID into the matching plan in `plans.js`, replacing
   `REPLACE_ME`

## 2. Set up the webhook

1. Dashboard → **Settings → Webhooks → Add webhook**
2. URL: `https://<your-backend-url>/api/webhook/lemonsqueezy`
3. Select the `order_created` event
4. Lemon Squeezy gives you a **signing secret** — save it, you'll need it
   for `LEMONSQUEEZY_WEBHOOK_SECRET`

## 3. Environment variables

Copy `.env.example` to `.env` locally, or set these directly in Render's
Environment Variables tab:

- `LEMONSQUEEZY_API_KEY` — Settings → API → Create API Key
- `LEMONSQUEEZY_STORE_ID` — Settings → Stores → click your store, ID is
  in the URL or store details
- `LEMONSQUEEZY_WEBHOOK_SECRET` — from step 2 above
- `CLIENT_SUCCESS_URL` / `CLIENT_CANCEL_URL` — your Netlify site URL
- `ESIM_PROVIDER` — leave as `mock` until Airalo approves you

## 4. Test the flow

Once deployed, hit the checkout endpoint:

```bash
curl -X POST https://<your-backend-url>/api/checkout/create-session \
  -H "Content-Type: application/json" \
  -d '{"planId":"jp_5gb_7d"}'
```

This returns a `checkoutUrl` — open it, complete a test purchase (Lemon
Squeezy has its own test mode toggle in the dashboard), and the webhook
should fire, provisioning a mock eSIM. Poll the order to confirm:

```bash
curl https://<your-backend-url>/api/orders/<orderId>
```

## 5. Connect a real eSIM provider

Same as before — see `esimProvider.js`. Once Airalo approves you, fill in
`AIRALO_CLIENT_ID` / `AIRALO_CLIENT_SECRET` and set `ESIM_PROVIDER=airalo`.
Nothing else in the app needs to change.

## Notes for production

- Swap `db.js`'s in-memory store for a real database — orders vanish on
  server restart right now.
- Add retry/alerting on provisioning failure.
- Email the QR code as a fallback in case the customer closes the tab.
